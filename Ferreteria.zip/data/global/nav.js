export default {
    "nav" : [
        {label: 'Inicio', uri: 'index.html'},
        {label: 'Nosotros', uri: 'nosotros.html'},
        {label: 'Programas', uri: 'programas.html'},
        {label: 'Galeria', uri: 'galeria.html'},
        {label: 'Ayuda', uri: 'ayuda.html'},
        {label: 'Blog', uri: 'blog.html'},
        {label: 'Eventos', uri: 'eventos.html'},
    ]
}