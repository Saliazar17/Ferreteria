export const getHeroData = ()=>({
    hero: {
        sImgUrl:'/img/organi2.jpg',
        mImgUrl:'/img/organi2.jpg',
        lImgUrl:'/img/organi2.jpg',
        heroTitle:"'Ferreteria Mafermas'",
        body: '<p>Somos una Microempresa que busca ofrecer un buen servicio, materiales ferreteros demandantes y adaptados a las necesidades de nuestros clientes.</p>'
    }
})